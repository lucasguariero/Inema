# INEMA — Sistema GLA / Módulo de Fiscalização (DIFIS)
## Pacote de Entrega Oficial para Equipe de Desenvolvimento

Este pacote contém o front-end completo e modernizado do **INEMA (GLA)**, incluindo o novo **Módulo de Fiscalização (DIFIS)** construído estritamente sob os padrões de design e componentes do **Filament 5.x**.

---

### 📁 Estrutura do Pacote

```text
.
├── src/                          # Código-fonte React 19 + TypeScript + Tailwind CSS
│   ├── components/
│   │   ├── filament/             # Componentes oficiais padrão Filament (FilamentSelect, Table, StatsOverview, InputWrapper, etc.)
│   │   ├── dashboard/            # Widgets, gráficos e tabelas do Dashboard Executivo
│   │   └── layout/               # Header, Sidebar institucional e navegação
│   ├── pages/
│   │   └── fiscalizacao/         # Telas oficiais de Fiscalização (DOR001, DOR003, DOR004, DOR005)
│   │       ├── ConsultaInternaPage.tsx   # Painel Interno DIFIS / Consultar Registros (DOR005)
│   │       ├── ConsultaExternaPage.tsx   # Consulta Cidadão (RD e RE)
│   │       ├── EmergenciaInternaPage.tsx # Cadastro de Emergência Química Interna (DOR003)
│   │       ├── EmergenciaExternaPage.tsx # Comunicação Externa de Acidente Químico (DOR004)
│   │       ├── DenunciaInternaPage.tsx   # Cadastro Interno de Denúncia Ambiental (DOR001)
│   │       └── DenunciaExternaPage.tsx   # Registro de Denúncia pelo Cidadão (Gov.br)
│   ├── data/                     # Mocks estruturados com dados regulatórios da Bahia
│   └── App.tsx                   # Roteador principal SPA
│
├── filament/                     # Recursos de Backend em Filament PHP 5.x (Laravel)
│   ├── app/Filament/
│   │   ├── AdminPanelProvider.php        # Configuração do painel Filament com tema INEMA
│   │   ├── Resources/
│   │   │   ├── OcorrenciaFiscalizacaoResource.php # Resource unificado de Fiscalização
│   │   │   ├── DenunciaAmbientalResource.php      # Form & Table de Denúncias (DOR001)
│   │   └── Widgets/                              # Widgets Filament (Estatísticas, Aging, etc.)
│   └── README_FILAMENT_INTEGRATION.md            # Guia passo a passo de integração PHP/Laravel
│
├── dist/                         # Build estático otimizado de produção pronto para deploy
├── public/                       # Imagens, logotipos oficiais do INEMA e assets estáticos
├── scripts/                      # Scripts auxiliares de build do Vite
├── index.html                    # Ponto de entrada HTML
├── package.json                  # Dependências do projeto
├── tailwind.config.ts            # Configurações de cores e tokens do INEMA
├── vite.config.mts               # Configuração do Vite
└── vercel.json                   # Regras de rewrite para Single Page Application (SPA)
```

---

### 🚀 Como Executar o Front-end

1. **Instalar dependências**:
   ```bash
   npm install
   ```

2. **Rodar em modo de desenvolvimento**:
   ```bash
   npm run dev
   ```
   Acesse: `http://localhost:5173`

3. **Gerar build de produção**:
   ```bash
   npm run build
   ```

4. **Visualizar build compilado**:
   ```bash
   npm run preview
   ```

---

### 🧩 Integração com Filament PHP (Laravel)

Na pasta `filament/` encontram-se as classes prontas para inclusão direta em projetos Laravel com Filament 5.x:
- **Painel e Tema**: `filament/app/Filament/AdminPanelProvider.php`
- **Resources e Schemas**: `filament/app/Filament/Resources/` contendo schemas de formulário (`Form`), colunas de tabelas (`Table`), filtros e ações mapeados conforme os documentos de requisitos oficiais (DOR001, DOR003, DOR004, DOR005).
- **Documentação de Handover**: Consulte `filament/README_FILAMENT_INTEGRATION.md` para o roteiro de migração e injeção de dependências no Laravel.

---

### 🛡️ Garantias de Qualidade

- **100% Livre de Selects Nativos**: Todos os dropdowns utilizam `FilamentSelect` com popovers customizados, pesquisa dinâmica (`searchable`) e tema dark/light.
- **Tabela sem Scroll Horizontal**: A tabela de Consulta Interna adapta-se a 100% da largura útil sem necessidade de rolagem lateral nas resoluções padrão (1280px a 1920px).
- **Zero Artefatos de QA ou Testes**: Este pacote contém estritamente o código de produção e handoff da aplicação.
