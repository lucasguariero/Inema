import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: ["class"],
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'inema-blue': {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#0073C4',
          600: '#005ea3',
          700: '#004a82',
          800: '#003e6b',
          900: '#003358',
        },
        'inema-green': {
          50: '#f4fbf0',
          100: '#e5f5da',
          200: '#cdebb9',
          300: '#aedc91',
          400: '#8cc668',
          500: '#78C043',
          600: '#5e9c31',
          700: '#487a24',
          800: '#355c1a',
          900: '#234010',
        },
        forest: {
          800: '#0a2720',
          900: '#061814',
          950: '#020b09',
        },
        blue: {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#0073C4',
          600: '#005ea3',
          700: '#004a82',
          800: '#003e6b',
          900: '#003358',
        },
        green: {
          50: '#f4fbf0',
          100: '#e5f5da',
          200: '#cdebb9',
          300: '#aedc91',
          400: '#8cc668',
          500: '#78C043',
          600: '#5e9c31',
          700: '#487a24',
          800: '#355c1a',
          900: '#234010',
        },
        slate: {
          50: '#f8fafc',
          100: '#f1f5f9',
          200: '#e2e8f0',
          300: '#cbd5e1',
          400: '#94a3b8',
          500: '#64748b',
          600: '#475569',
          700: '#334155',
          800: '#1e293b',
          900: '#0f172a',
        },
      },
      fontFamily: {
        sans: ["Inter", "-apple-system", "BlinkMacSystemFont", "sans-serif"],
      },
      boxShadow: {
        "2xs": "0 1px 2px rgba(15, 23, 42, 0.04)",
        xs: "0 1px 3px rgba(15, 23, 42, 0.06), 0 1px 2px rgba(15, 23, 42, 0.04)",
        card: "0 1px 3px rgba(15, 23, 42, 0.05), 0 1px 2px rgba(15, 23, 42, 0.03)",
        "card-hover": "0 8px 20px -3px rgba(15, 23, 42, 0.08), 0 3px 8px -2px rgba(15, 23, 42, 0.04)",
      },
      borderRadius: {
        "2xl": "1rem",
        "3xl": "1.5rem",
      },
    },
  },
  plugins: [],
};

export default config;
